import React, { useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import * as XLSX from 'xlsx';

function PatentSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [sortBy, setSortBy] = useState('title');
  const [sortOrder, setSortOrder] = useState('asc');

  const sortedResults = [...results].sort((a, b) => {
    if (a[sortBy] < b[sortBy]) return sortOrder === 'asc' ? -1 : 1;
    if (a[sortBy] > b[sortBy]) return sortOrder === 'asc' ? 1 : -1;
    return 0;
  });

  const handleSort = (field) => {
    if (field === sortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const downloadExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(results);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Patents");
    
    // Generate Excel file as an array buffer
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    
    // Create Blob from the array buffer
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    // Create download link and trigger download
    const url = window.URL.createObjectURL(data);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'patents_results.xlsx';
    link.click();
    
    // Clean up
    window.URL.revokeObjectURL(url);
  };

  const searchPatent = async () => {
    setIsLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/search', { query });
      setResults(response.data.results);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl p-6 space-y-6">
      <motion.h1
        className="text-4xl font-bold text-center text-cyan-400"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Recherche de Brevets Futuriste
      </motion.h1>
      <motion.div
        className="flex space-x-2"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <input
          type="text"
          className="flex-grow p-2 bg-gray-800 text-white border border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400"
          placeholder="Entrez un brevet"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button
          className="px-4 py-2 bg-cyan-500 text-gray-900 hover:bg-cyan-400 transition-colors duration-300"
          onClick={searchPatent}
        >
          Rechercher
        </button>
      </motion.div>
      {isLoading ? (
        <div className="text-center text-cyan-400 animate-pulse">Chargement des résultats...</div>
      ) : results.length > 0 ? (
        <motion.div
          className="space-y-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="flex justify-between items-center">
            <div className="space-x-2">
              <button
                className="px-2 py-1 bg-cyan-500 text-gray-900 hover:bg-cyan-400 transition-colors duration-300"
                onClick={() => handleSort('title')}
              >
                Trier par titre {sortBy === 'title' && (sortOrder === 'asc' ? '▲' : '▼')}
              </button>
              <button
                className="px-2 py-1 bg-cyan-500 text-gray-900 hover:bg-cyan-400 transition-colors duration-300"
                onClick={() => handleSort('snippet')}
              >
                Trier par extrait {sortBy === 'snippet' && (sortOrder === 'asc' ? '▲' : '▼')}
              </button>
            </div>
            <button
              className="px-4 py-2 bg-fuchsia-500 text-gray-900 hover:bg-fuchsia-400 transition-colors duration-300"
              onClick={downloadExcel}
            >
              Télécharger Excel
            </button>
          </div>
          <ul className="space-y-4">
            {sortedResults.map((result, index) => (
              <motion.li
                key={index}
                className="bg-gray-800 p-4 border-l-4 border-cyan-400"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <h3 className="text-xl font-semibold text-cyan-400 mb-2">{result.title}</h3>
                <p className="text-gray-300 mb-2">{result.snippet}</p>
                <a
                  href={result.link}
                  className="text-fuchsia-400 hover:text-fuchsia-300 transition-colors duration-300"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Voir le brevet
                </a>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      ) : (
        <p className="text-center text-fuchsia-400">Aucun résultat trouvé</p>
      )}
    </div>
  );
}

export default PatentSearch;

