import React from 'react';
import PatentSearch from './components/PatentSearch';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <PatentSearch />
    </div>
  );
}

export default App;

