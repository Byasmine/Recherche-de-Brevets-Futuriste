module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cyan: {
          400: '#00ffff',
          500: '#00e5e5',
        },
        fuchsia: {
          300: '#ff66ff',
          400: '#ff00ff',
        },
      },
    },
  },
  plugins: [],
}

