import React, { useState } from "react";
import axios from "axios";
import config from "./config";
import { motion } from "framer-motion";
import "./styles/globals.css";

function App() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const searchPatent = async () => {
    setIsLoading(true);
    try {
      const response = await axios.post(`${config.apiUrl}/search`, { query });
      setResults(response.data.results);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container">
      <motion.h1
        className="title"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Recherche de Brevets Futuriste
      </motion.h1>
      <motion.div
        className="search-container"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <input
          type="text"
          className="search-input"
          placeholder="Entrez un brevet"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="search-button" onClick={searchPatent}>
          Rechercher
        </button>
      </motion.div>
      {isLoading ? (
        <div className="loading">Chargement des résultats...</div>
      ) : results.length > 0 ? (
        <motion.ul
          className="results-list"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          {results.map((result, index) => (
            <motion.li
              key={index}
              className="result-item"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <h3 className="result-title">{result.title}</h3>
              <p className="result-snippet">{result.snippet}</p>
              <a
                href={result.link}
                className="result-link"
                target="_blank"
                rel="noopener noreferrer"
              >
                Voir le brevet
              </a>
            </motion.li>
          ))}
        </motion.ul>
      ) : (
        <p className="no-results">Aucun résultat trouvé</p>
      )}
    </div>
  );
}

export default App;

